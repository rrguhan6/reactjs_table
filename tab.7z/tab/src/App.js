import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import "./App.css";
import Table from "./components/Table";
import Form from "./components/Form";
import Header from "./components/Header";

function App() {
  return (
    <div className="App">
      <Router>
        <Header />
        <Switch>
          <Route exact path="/" component={Table} />
          <Route exact path="/form" component={Form} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
